@echo off
setlocal
set DIRNAME=%~dp0
set WRAPPER_JAR=%DIRNAME%gradle\wrapper\gradle-wrapper.jar
if exist "%WRAPPER_JAR%" (
  java -Xmx64m -Xms64m -jar "%WRAPPER_JAR%" %*
) else (
  where gradle >nul 2>nul
  if %ERRORLEVEL% equ 0 (
    gradle %*
  ) else (
    echo Error: gradle-wrapper.jar not found and system gradle is not installed.
    echo Open this folder in Android Studio or run: gradle wrapper
    exit /b 1
  )
)
endlocal
